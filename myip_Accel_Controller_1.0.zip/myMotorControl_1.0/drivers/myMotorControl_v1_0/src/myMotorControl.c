

/***************************** Include Files *******************************/
#include "myMotorControl.h"

/************************** Function Definitions ***************************/
